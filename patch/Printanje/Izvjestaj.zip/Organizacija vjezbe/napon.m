function [ V ] = napon (cm)
    Vmax=4;Vmin=0.5;opsegD=5;opsegG=110;
    a=(Vmax-Vmin)/(opsegG-opsegD);
    b=(Vmin*opsegG-Vmax*opsegD)/(opsegG-opsegD);
    V=a*cm+b;
end
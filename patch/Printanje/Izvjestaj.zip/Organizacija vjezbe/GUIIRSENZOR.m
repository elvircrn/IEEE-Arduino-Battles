function varargout = GUIIRSENZOR(varargin)
% GUIIRSENZOR MATLAB code for GUIIRSENZOR.fig
%      GUIIRSENZOR, by itself, creates a new GUIIRSENZOR or raises the existing
%      singleton*.
%
%      H = GUIIRSENZOR returns the handle to a new GUIIRSENZOR or the handle to
%      the existing singleton*.
%
%      GUIIRSENZOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIIRSENZOR.M with the given input arguments.
%
%      GUIIRSENZOR('Property','Value',...) creates a new GUIIRSENZOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUIIRSENZOR_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUIIRSENZOR_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUIIRSENZOR

% Last Modified by GUIDE v2.5 18-Apr-2016 23:11:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUIIRSENZOR_OpeningFcn, ...
                   'gui_OutputFcn',  @GUIIRSENZOR_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before GUIIRSENZOR is made visible.
function GUIIRSENZOR_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUIIRSENZOR (see VARARGIN)

% Choose default command line output for GUIIRSENZOR
handles.output = hObject;

global trenutno
trenutno=0;

global trenutno2
trenutno2=0;

global praveS
praveS=[ 0.282724409672831,0,110;...
        0.729921578947367	-163.238958149990	156.151638078564;...
        1.25493859649123	-32.6059525211568	60.9184682941602;...
        1.84183333333334	-12.1545362465634	35.3866300101289;...
        3.25711111111111	-5.66572237960336	23.4538873150770;...
        5	0	5];

global polinom
polinom=[-7.361,69.03,-235.4, 327.4, -71.14, -237.1, 180.1];

Vmax=4;Vmin=1;opsegD=5;opsegG=110;

global a
a=(Vmax-Vmin)/(opsegG-opsegD);

global b
b=(Vmin*opsegG-Vmax*opsegD)/(opsegG-opsegD);

global izlazna
izlazna=Vmin;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUIIRSENZOR wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUIIRSENZOR_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function [ cm ] = dekodirajucm (u)
    global praveS
    for j=1:size(u,2)
        for i=1:size(praveS,1)
            if u(j)<praveS(i,1)
                cm(j) = praveS(i,2)*u(j)+praveS(i,3);
                break;
            end
        end
    end
    
function [ cm ] = dekodirajucmPolinom(u)
    global polinom
    cm=0;
    for i=0:6 %polinom sestog stepena
        cm=cm+polinom(i+1)*u.^(6-i);
    end

function [ V ] = napon (cm)
    global a
    global b
    V=a*cm+b;
    
    
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)

global trenutno;
if trenutno==1
    trenutno=0;
    return
end

kanalUlaza = str2num(get(handles.edit3,'String'));
AI = analoginput('mcc',0);
addchannel(AI,kanalUlaza);
sampleUni=200;
set(AI,'SampleRate',sampleUni);
set(AI,'SamplesPerTrigger',inf); 

start(AI);
trenutno=1;
set(handles.pushbutton2,'String','Kraj');

global izlazna
izlazna=1;

dataold=[];
told=[];

while(1)
    
    refresh = str2num(get(handles.edit2,'String'));
    
    [data,t]=getdata(AI,(refresh*sampleUni));
    told=[told t];
    dataold=[dataold data];
    plot(handles.axes1,told,dekodirajucm(dataold));
    xlabel('t (s)');
    ylabel('x (cm)');
    if trenutno==0
        break;
    end
    data=sort(data);
    voltaza=data(round(size(data,2)/2));
    cm=dekodirajucm(voltaza);
    cmPolinom=dekodirajucmPolinom(voltaza);
    linNapon=napon(cm);
    cm
    izlazna=linNapon;
    
    set(handles.text3,'String',num2str(cm));
    set(handles.text5,'String',num2str(cmPolinom));
    set(handles.text8,'String',num2str(voltaza*1000));
    set(handles.text11,'String',num2str(linNapon*1000));

 end
 
set(handles.pushbutton2,'String','Start');
trenutno=0;
delete AI



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global trenutno2;
if trenutno2==1
    trenutno2=0;
    return
end

global izlazna

kanalIzlaza = str2num(get(handles.edit1,'String'));
refresh = str2num(get(handles.edit2,'String'));

trenutno2=1;
sampleRate=8000;

while 1
    AO = analogoutput('winsound',0);%%%%%%%
    addchannel(AO,kanalIzlaza);
    set(AO,'SampleRate',sampleRate)
    new=ones(1,round(refresh*sampleRate))'*izlazna;
    putdata(AO,new);
    start(AO);
    while strcmp(AO.Running,'On')
    end
    display(izlazna);
    delete(AO);
    if trenutno2==0
        break;
    end
end

trenutno2=0;

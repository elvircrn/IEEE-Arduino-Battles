function [ cm ] = prekoPolinoma( u )
%PREKOPOLINOMA Summary of this function goes here
%   Detailed explanation goes here
    polinom=[-7.361,69.03,-235.4, 327.4, -71.14, -237.1, 180.1];
    cm=0;
    for i=0:6 %polinom sestog stepena
        cm=cm+polinom(i+1)*u.^(6-i);
    end
end


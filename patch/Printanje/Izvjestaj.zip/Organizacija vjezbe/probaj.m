function AA = probaj( x,y )
%PROBAJ Summary of this function goes here
%   Detailed explanation goes here
    n = size(y,2);
    if (n<2)
        error('premale matrice proslijedjenje');
    end
    D = n*(x*x')-sum(x)^2;
    a = (n*(x*y')-sum(x)*sum(y))/D;
    b = (sum(y)*(x*x')-sum(x)*(x*y'))/D;
    y_kar=a*x+b;
    %plot(x,y_kar);
    AA=sum((y-y_kar).^2);
end

